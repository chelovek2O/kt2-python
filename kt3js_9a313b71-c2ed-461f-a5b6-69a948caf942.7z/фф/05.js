function checkElem(array, callback) {
    
    for (let element of array) {
        
        if (callback(element)) {
            return true;
        }
    }

    return false; 
}


let array = [1, 3, 7, 9, 10];
let isEvenPresent = checkElem(array, function(num) {
    return num % 2 === 0;
});

if (isEvenPresent) {
    console.log("Есть четные числа в массиве.");
} else {
    console.log("Нет четных чисел в массиве.");
}
