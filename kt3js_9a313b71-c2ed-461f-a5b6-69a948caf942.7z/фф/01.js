


checkElem(22);  

function checkElem(num)
 {
    if (num % 7 === 0) {
        console.log('true');
    } else {
        console.log('false');
    }
}