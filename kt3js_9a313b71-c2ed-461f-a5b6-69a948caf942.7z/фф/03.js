function sumElems(array) {
    let sum = 0;

    array.forEach(function(element) {
        
        let num = parseFloat(element);

        
        if (!isNaN(num)) {
            sum += num; 
        }
    });

    return sum;
}

let stringArray = ["123", "45", "мяу", "7", "9.5"];
let result = sumElems(stringArray);
console.log("Сумма элементов, которые можно преобразовать в число без NaN:", result);
