function reverseIndex(array) {
    let length = array.length;
    let mid = Math.floor(length / 2);

    for (let i = 0; i < mid; i++) {
       
        let temp = array[i];
        array[i] = array[length - 1 - i];
        array[length - 1 - i] = temp;
    }

    return array;
}


let originalArray = [1, 2, 3, 4, 5];
console.log(" массив:", originalArray);

let reversedArray = reverseIndex(originalArray);
console.log(" массив после переворота :", reversedArray);
