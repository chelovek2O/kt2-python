function changeElem(array, n) {
   
    let newArray = array.map(function(item) {
        return item * n;
    });

    return newArray;
}

let originalArray = [1, 4, 8, 4, 33];
let multiplier = 88;
let modifiedArray = changeElem(originalArray, multiplier);

console.log("Исходный массив:", originalArray);
console.log("Массив после умножения каждого элемента на", multiplier, ":", modifiedArray);
