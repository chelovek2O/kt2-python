function logString(...args) {
    let concatenatedString = args.join(' ');
    console.log("${concatenatedString}");
}

logString("Hello", "my", "world!");
