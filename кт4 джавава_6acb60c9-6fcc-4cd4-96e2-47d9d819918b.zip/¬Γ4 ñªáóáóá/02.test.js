let array = [
    { id: 1, name: 'apple' },
    { id: 2, name: 'watermelon' },
    { id: 3, name: 'qiwi' },
    { id: 4, name: 'lemon' }
];

function transformObjectsToArray(arr) {
    return arr.map(obj => Object.values(obj));
}


const expectedResult = [
    [1, "apple"],
    [2, "watermelon"],
    [3, "qiwi"],
    [4, "lemon"]
];
const result = transformObjectsToArray(array);

if (JSON.stringify(result) === JSON.stringify(expectedResult)) {
    console.log('Тест пройден: каждый объект успешно преобразован в новый массив значений свойств.');
} else {
    console.log('Тест не пройден: преобразование объектов в массивы значений свойств не выполнено корректно.');
}
