class Email {
    constructor(email) {
        this._email = email;
    }

    get email() {
        return this._email;
    }

    set email(newEmail) {
        this._email = newEmail;
    }
}

class Contact extends Email {
    constructor(email, phone) {
        super(email);
        this._phone = phone;
    }

    get phone() {
        let phoneType;
        if (this._phone.length === 12) {
            phoneType = "Мобильный";
        } else if (this._phone.length === 18) {
            phoneType = "Городской";
        } else if (!this._phone.includes('+')) {
            phoneType = "Неизвестный";
        }
        return { number: this._phone, type: phoneType };
    }

    set phone(newPhone) {
        this._phone = newPhone;
    }
}


const contact1 = new Contact('example@example.com', '+123456789012');
console.log(contact1.email); 
console.log(contact1.phone); 

const contact2 = new Contact('another@example.com', '123456789012345678');
console.log(contact2.email); 
console.log(contact2.phone); 
