let users = [];

function addUser(firstName, lastName, age) {
    const id = users.length + 1; 
    const newUser = { id, firstName, lastName, age };
    users.push(newUser); 
}

function updateUser(id, firstName, lastName, age) {
    const userIndex = users.findIndex(user => user.id === id);
    if (userIndex !== -1) {
        users[userIndex] = { id, firstName, lastName, age }; // Обновление данных пользователя по id
    } else {
        console.log("Пользователь с id ", $,{id}, "не найден.");
    }
}

function deleteUser(id) {
    users = users.filter(user => user.id !== id); 
}


addUser('John', 'Doe', 30); 
addUser('Alice', 'Smith', 25);

console.log(users); 

updateUser(2, 'Alice', 'Johnson', 26); 
deleteUser(1); 

console.log(users); 
