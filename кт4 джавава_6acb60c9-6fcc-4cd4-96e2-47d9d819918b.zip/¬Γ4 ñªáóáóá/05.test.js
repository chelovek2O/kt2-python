function generateArray(array) {
    return array.map(item => {
        if (Array.isArray(item)) {
            return item;
        } else if (typeof item === 'object' && item !== null) {
            return Object.values(item);
        } else {
            return item;
        }
    });
}


test('Generate array test', () => {
    const inputArray = [[1], {id: 40}, [100], [300], {part: 10}];
    const expectedOutput = [[1], [40], [100], [300], [10]];
    expect(generateArray(inputArray)).toEqual(expectedOutput);
});
