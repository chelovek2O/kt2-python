let users = []; // Инициализация массива пользователей

function addUser(firstName, lastName, age) {
    const id = users.length + 1; // Формирование id нового пользователя
    const newUser = { id, firstName, lastName, age };
    users.push(newUser); // Добавление нового пользователя в массив
}

function updateUser(id, firstName, lastName, age) {
    const userIndex = users.findIndex(user => user.id === id);
    if (userIndex !== -1) {
        users[userIndex] = { id, firstName, lastName, age }; 
    } else {
        console.log("Пользователь с id ", $,{id}, "не найден.");
    }
}

function deleteUser(id) {
    const initialLength = users.length;
    users = users.filter(user => user.id !== id); 
    if (initialLength === users.length) {
        console.log("Пользователь с id ", $,{id}, "не найден.");
    }
}


addUser('John', 'Doe', 30); 
addUser('Alice', 'Smith', 25);

console.log(users); 

updateUser(2, 'Alice', 'Johnson', 26); 
updateUser(3, 'Bob', 'Brown', 35); 

deleteUser(1); 
deleteUser(4); 

console.log(users); 
