const obj = {
    price1: 100,
    price2: 150,
    price3: 200,
    price4: 100,
    price5: 150,
};

function calculateTotalSum(obj) {
    return Object.values(obj).reduce((acc, current) => acc + current, 0);
}


const expectedResult = 700;
const result = calculateTotalSum(obj);

if (result === expectedResult) {
    console.log('Тест пройден: итоговая сумма значений свойств объекта соответствует ожидаемому результату.');
} else {
    console.log('Тест не пройден: итоговая сумма значений свойств объекта не соответствует ожидаемому результату.');
}
