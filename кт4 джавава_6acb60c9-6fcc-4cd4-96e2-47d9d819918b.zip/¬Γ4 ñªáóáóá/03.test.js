function logString(...args) {
    let concatenatedString = args.join(' ');
    console.log("${concatenatedString}");
}


function testLogString() {
    const consoleLogSpy = jest.spyOn(console, 'log').mockImplementation((msg) => {
        expect(msg).toBe('"Hello my world!"');
    });

    logString("Hello", "my", "world!");

    consoleLogSpy.mockRestore();
    console.log('Тест пройден: строка успешно выведена в консоль в кавычках.');
}

testLogString();
